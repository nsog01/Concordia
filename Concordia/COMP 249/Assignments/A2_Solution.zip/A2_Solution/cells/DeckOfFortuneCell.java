package cells;

import java.util.Random;

import racers.Racer;
/**
 * Defines the game action when racers lands
 * on a special Deck of Fortune Cell
 */

public class DeckOfFortuneCell extends RegularCell{
	
	public static int nextCard;
	public static int BONUS_ENERGY = 30;

	/** Default constructor
	 * 	Sets the top card to a number between 0 and 9
	 */
	public DeckOfFortuneCell()
	{
		Random randomGenerator = new Random();
		nextCard = randomGenerator.nextInt(10);
	}

	/** Accessor method
	 * @return	nextCard 	the number of the next card
	 */
	public int getNextCard()
	{
		return nextCard+1;
	}
	
	public int pickCard(int location)
	{
		System.out.print("Picking a card of fortune. ");
		System.out.println("Current card: " + nextCard);
		switch(nextCard+1)
		{
		case 1: location -= 9;
			System.out.print("Go back 9. ");
			break;
		case 2: location = 0;
			System.out.print("Go back to the beginning. ");
			break;
		case 3: location -= 3;
			System.out.print("Go back 3. ");
			break;
		case 4: location -= 8;
			System.out.print("Go back 8. ");
			break;
		case 5: location += 2;
			System.out.print("Go forward 2. ");
			break;
		case 6: location += 1;
			System.out.print("Go forward 1. ");
			break;
		case 7: location += 3;
			System.out.print("Go forward 3. ");
			break;
		case 8: location = 0;
			System.out.print("Go back to the beginning. ");
			break;
		case 9: location -= 4;
			System.out.print("Go back 4. ");
			break;
		case 10: location += 6;
			System.out.print("Go forward 3. ");
			break;
		} // switch
		System.out.println("You are at location " + location);

		// Prepare for next turn
		nextCard = (++nextCard % 10);

		return location;
	}// method pickCard

	/**
	 * Overrides the method updateEnergy on
	 * RegularCell according to special
	 * position on board - Deck of Fortune.
	 * @param	racers current racers on board
	 * @param	p special position
	 */
	@Override
	public void updateEnergy(int p, Racer player){

		super.updateEnergy(p, player);
		player.setEnergy(player.getEnergy()+BONUS_ENERGY);
	}
	
	/**
	 * Display code of the special cell.
	 */

	@Override
	public String toString(){
		return "d";
	}
	
}
