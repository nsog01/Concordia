package cells;

import racers.Racer;

/**
 * Defines the game action when racers lands
 * on a special Skip Cell
 */
public class SkipCell extends RegularCell{

	public void updateEnergy(int p, Racer player){

		player.setEnergy(player.getEnergy()-p);
	}

	/**
	 * Display code of the special cell.
	 */
	@Override
	public String toString(){
		return "s";
	}

}
