package cells;

import racers.Racer;

/**
 * Defines the game action when racers lands
 * on a special Wheel of Fortune Cell
 */
public class WheelOfFortuneCell extends RegularCell{
	
	/**
	 * Simulates the spinning of the wheel of fortune. There are 
	 * 8 possible slots the wheel can stop on.
	 * @param 	location location racers at
	 * @return	new location
	 */
	public  int spinTheWheel(int location)
	{
		System.out.print("Spinning the wheel of fortune. ");
		switch((int) (Math.random()* 8 + 1))
		{
		case 1: location += 1;
		System.out.print("Go forward 1. ");
		break;
		case 2: location += 2;
		System.out.print("Go forward 2. ");
		break;
		case 3: location = 0;
		System.out.print("Go back to the beginning. ");
		break;
		case 4 : location -=4;
		System.out.print("Go back 4. ");
		break;
		case 5 : location -=6;
		System.out.print("Go back 6. ");
		break;
		case 6 : location -=7;
		System.out.print("Go back 7. ");
		break;
		case 7 : location -=8;
		System.out.print("Go back 8. ");
		break;
		case 8 : location -=9;
		System.out.print("Go back 9. ");
		break;
		}// switch
		System.out.println("You are now at location " + location);
		return location;
	} // method spinTheWheel
	
	/**
	 * Overrides the method updateEnergy on   
	 * RegularCell according to special 
	 * position on board - Wheel of Fortune.
	 * @param	racers current racers on board
	 * @param	p special position
	 */
	@Override
	public void updateEnergy(int p, Racer player){
		
		super.updateEnergy(p, player);		
		player.setEnergy(player.getEnergy()*2);
	}
	
	/**
	 * Display code of the special cell.
	 */	
	@Override
	public String toString(){
		return "w";
	}


}
