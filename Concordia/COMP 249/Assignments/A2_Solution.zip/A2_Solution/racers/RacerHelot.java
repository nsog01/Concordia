package racers;

/**
 * Special racers type Helot
 */
public class RacerHelot extends Racer{

	//Constructor with Helot characteristics
	public RacerHelot(String Name){
		energy = 60;
		position = 40;
		name = "h_" + Name;
	}

}
