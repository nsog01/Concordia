package racers;

/**
 * Special racers type Perioikoi
 */
public class RacerPerioikoi extends Racer{

	//Constructor with Perioikoi characteristics
	public RacerPerioikoi(String Name){
		energy = 130;
		position = 0;
		name = "p_" + Name;
	}
	
}
