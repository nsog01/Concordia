package racers;

/**
 * Special racers type Perioikoi
 */
public class RacerSpartiate extends Racer{
	
	//Constructor with Spartiate characteristics
	public RacerSpartiate(String Name) {
		name = Name;
		energy = 100;
		position = 20;
	}

	
}
