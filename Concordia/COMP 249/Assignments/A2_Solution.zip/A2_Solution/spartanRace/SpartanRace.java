package spartanRace;

import java.util.Scanner;

import cells.DeckOfFortuneCell;
import cells.JokerCell;
import cells.RegularCell;
import cells.SkipCell;
import cells.WheelOfFortuneCell;

import racers.Racer;
import racers.RacerHelot;
import racers.RacerPerioikoi;
import racers.RacerSpartiate;

/**
 * Driver class to execute the 
 * Spartan Race.
 *
 */
public class SpartanRace {

	public static void main(String[] args) {
		// Constants
		final int anotherGame = 1;

		// Variable declaration
		Racer [] player;
		Dice dice = new Dice();
		RegularCell regCell = new RegularCell();
		DeckOfFortuneCell deckCell = new DeckOfFortuneCell();
		WheelOfFortuneCell wheelCell = new WheelOfFortuneCell();
		JokerCell jokerCell = new JokerCell();
		SkipCell skipCell = new SkipCell();
		RaceTrack board = new RaceTrack();

		Scanner keyIn = new Scanner(System.in);
		int whoseTurn = 0, roll = 0, numOfWinners, numOfSlaves, play;
		boolean testMode;

		//Welcome message
		System.out.println(" Spartan Race - Version 1.0\n-----------------------------------\n");
		do{
			player = setUpRacers(keyIn);

			// Regular or test mode?
			System.out.print("\nTest Mode? (Enter 1 for test mode): ");
			testMode = (keyIn.nextInt() == 1);


			//And the race is on!!!
			System.out.println( "\nWelcome racers ... how many of you will be sold as slaves today ....hahaha.\n" +
					"Ready ...  Set  ... Go!");
			do
			{
				board.resetTrack(); // set count of each location back to 0

				// Each racers moves
				for(int i = 0; i < player.length; i++)
				{
					//Check if racers energy is enough to continue the round
					if (player[i].getEnergy() > 0)
					{
						do
						{
							//Keep rolling the dice in this case.
							System.out.print("\nPlayer " + player[i].getName()+ "  - Enter a " + (i+1)+" to roll the dice ");
							whoseTurn = keyIn.nextInt();
						}while (whoseTurn != (i+1));

						//Set position if racers has chosen debug mode
						if(testMode)
						{
							System.out.println("Which position does racers move to? ");
							roll = keyIn.nextInt();
							player[i].setPosition(roll);
						}
						//If normal mode, execute rollDice and advance racers position
						else
						{
							roll = dice.rollDice();
							System.out.print(dice);
							player[i].advanceBy(roll);
							System.out.print(" At location " + player[i].getPosition() + ". ");
						}

						//Check if the racers has landed on a special location
						switch(board.getCode(player[i].getPosition()))
						{
						case "d":
							//if landed on Deck of Fortune, update energy according to Deck
							player[i].setPosition(deckCell.pickCard(player[i].getPosition()));
							deckCell.updateEnergy(roll, player[i]);
							break;
						case "s":
							//if landed on Skip, update energy according to Skip
							System.out.println("Moving to location 68. ");
							player[i].setPosition(68);
							skipCell.updateEnergy(roll, player[i]);
							break;
						case "w":
							//if landed on Wheel of Fortune, update energy according to Wheel
							player[i].setPosition(wheelCell.spinTheWheel(player[i].getPosition()));
							wheelCell.updateEnergy(roll, player[i]);
							break;
						case "?":
							//if landed on Joker, update energy according to Joker
							player[i].setPosition(jokerCell.cardOrWheel(player[i].getPosition()));
							jokerCell.updateEnergy(roll, player[i]);
							break;
						default:
							//if landed on a regular spot, update energy according normally
							regCell.updateEnergy(roll, player[i]);
							System.out.println("You reached a regular cell.");
						}
						board.addPlayer(player[i].getPosition());

						//After playing the round, check if racers energy is enough to continue on game
						if(player[i].getEnergy()<=0)
						{							
							System.out.print("Your energy level reached " + player[i].getEnergy() + ". \n" + player[i].getName() + " will be sold as a slave. \n");
						}
						//If his/her energy is enough, display the energy level of the round
						else
						{
							System.out.print("Your energy level is currently " + player[i].getEnergy() + ". \n");
						}
					}
					//If the energy is not enough at the beggining of the round, eliminate racers's turn
					else
					{
						System.out.print("\nPlayer " + player[i].getName()+ " will be sold as a slave at the end. \n");
					}

				}

				System.out.print(board);  // Dispay board

				//End of game: How many winners? Or are all slaves?
				numOfWinners = 0;
				numOfSlaves = 0;
				for (int i = 0; i < player.length; i++)
					if (player[i].getPosition() >= 90 && player[i].getEnergy() > 0)
						numOfWinners++;
					else if (player[i].getEnergy()<0)
						numOfSlaves++;
			}while (numOfWinners == 0 && (numOfSlaves < player.length));

			// And the winner(s)/slave(s) is/are
			winnersReport(numOfWinners, player);

			play = playAgain();  // Does the user want to play again?
		} while (play == anotherGame);

		// Closing message
		System.out.println("\n-->  Hope you enjoyed Version 1.0 of the Spartan Race game.  <--\n");
	}// end of main()


	// Static methods
	//---------------

	public static Racer[] setUpRacers(Scanner keyIn)
	{
		int numOfRacers, playerType;
		System.out.print("How many racers will there be (2 to 4)? ");

		// How many racers?
		do
		{
			numOfRacers = keyIn.nextInt();
			if (numOfRacers < 2 || numOfRacers > 4)
				System.out.print("\t"+numOfRacers + " racers(s) is not possible. The track can accommodate 2 to 4 players only.\n" +
						"So how many racers? ");
		} while (numOfRacers < 2 || numOfRacers > 4);

		// Get name of players and create Racer objects
		Racer [] player = new Racer[numOfRacers];
		for (int i = 0; i < numOfRacers; i++)
		{
			System.out.print("Name of Racer #" + (i +1) + " please: ");
			String name = keyIn.next();
			System.out.print("Select the type of racers: 1 - Spartiate | 2 - Helot | 3 - Perioikoi: ");
			do
			{
				playerType = keyIn.nextInt();
				if(playerType < 1 || playerType > 3)
					System.out.print("\t Player type "+playerType+ " is not available. Please select 1 for adult, 2 for elderly, 3 for child: ");
			}
			while (playerType < 1 || playerType > 3);

			//Create each different type of racers
			switch(playerType)
			{
			case 1:
				player[i] = new RacerSpartiate(name);
				break;
			case 2:
				player[i] = new RacerHelot(name);
				break;
			case 3:
				player[i] = new RacerPerioikoi(name);
				break;
			default:
				break;
			}
		}
		return player;
	} // method setUpRacers

	public static void winnersReport(int n, Racer[] p)
	{
		if(n > 0)
		{
			System.out.println("\n\nWe have " + n + (n > 1? " winners!":" winner!")+
					"\nCongratulations to:");
			for (int i = 0; i < p.length; i++)
				if(p[i].getPosition() >= 89 && p[i].getEnergy() > 0)
					System.out.println("\t" + p[i].getName());
			System.out.println(	"\nThe rest of you will be sold as slaves!\n");
		}
		else
		{
			for (int i = 0; i < p.length; i++)
				System.out.println("\t" + p[i].getName());
			System.out.println(	" will all be sold as slaves!\n");
		}
	} //method winnersReport

	public static int playAgain()
	{
		Scanner keyIn = new Scanner(System.in);
		System.out.print("Would you like to play again? (1 for yes) ");
		int again = keyIn.nextInt();
		return again;
	}// method playAgain



}
