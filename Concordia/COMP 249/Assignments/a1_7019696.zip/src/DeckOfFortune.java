//**************************************************************************************
//Assignment #1
//Written by: Jordan Hubscher, ID: 7019696
//For Comp 249 Section SA -Winter 2014
//**************************************************************************************

/* This program will be a simulated board-game. It will take into account how many players are playing (no less
 * than 2 and no more than 4) and what mode the users choose to play in (regular mode or debugging mode). Each player on his 
 * turn must roll two dice will determine which spot on the board he shall move to. When landing on certain spots on the 
 * board, the player will reach an obstacle and must either choose a card from the Deck of Fortune, or spin the 
 * Wheel of Fortune (in which either will determine a condition for the respective player). Whichever player surpasses or 
 * reaches the final place on the board wins. Also, if two players reach the same spot within the same turn, there is a tie.
*/

/**
 * 
 * @author Jordan Hubscher
 * @version 1.0
 * @see SpartanDriver
 * @see Dice
 * @see Player
 * @see GameBoard
 * @see WheelOfFortune
 *
 */

public class DeckOfFortune {
	
	private int card = 1;
	
	/**
	 * This method returns an integer value of the new position of the given player that picked the respective card from the deck.
	 * @param position Integer value of given player that picked the given card. The value represents that player's current position.
	 * @return Returns integer value representing the player's NEW position after drawing the card.
	 */
	public int pickCard(int position){
		int new_position = 0;
		
		switch(card){
		case 1: System.out.print("Picking a card of fortune. Current card " + card + " Go back 9.");
				position -= 9;
				new_position = position;
				card++;
				break;
		case 2: System.out.print("Picking a card of fortune. Current card " + card + " Go back to space 0.");
				new_position = position = 0;
				card++;
				break;
		case 3: System.out.print("Picking a card of fortune. Current card " + card + " Go back 3.");
				position -= 3;
				new_position = position;
				card++;
				break;
		case 4: System.out.print("Picking a card of fortune. Current card " + card + " Go back 8.");
				position -= 8;
				new_position = position;
				card++;
				break;
		case 5: System.out.print("Picking a card of fortune. Current card " + card + "  Go forward 2.");
				position += 2;
				new_position = position;
				card++;
				break;
		case 6: System.out.print("Picking a card of fortune. Current card " + card + "  Go forward 1.");
				position++;
				new_position = position;
				card++;
				break;
		case 7: System.out.print("Picking a card of fortune. Current card " + card + "  Go forward 3.");
				position += 3;
				new_position = position;
				card++;
				break;
		case 8: System.out.print("Picking a card of fortune. Current card " + card + "  Go back to space 0.");
				new_position = position = 0;
				card++;
				break;
		case 9: System.out.print("Picking a card of fortune. Current card " + card + "  Go back 4.");
				position -= 4;
				new_position = position;
				card++;
				break;
		case 10: System.out.print("Picking a card of fortune. Current card " + card + "  Go forward 6.");
				position += 6;
				new_position = position;
				card = 1;
				break;
		}
		return new_position;
	}
	
	/**
	 * This method accesses the card attribute of the calling object and returns its integer value.
	 * @return Returns the integer value of the numbered card in the deck (i.e. 1: first card, 2: second card, etc.)
	 */
	public int getCard(){
		return card;
	}
	
	/**
	 * Overrides toString method to return a formatted string of the calling object's instance variables.
	 * @returns Formatted string displaying calling object's information/attributes.
	 */
	public String toString(){
		String toString = "";
		switch(card){
		case 1: toString = "Current card is " + card + "Go back 9 spaces.";
				break;
		case 2: toString = "Current card is " + card + "Go back to space 0.";
				break;
		case 3: toString = "Current card is " + card + "Go back 3 spaces.";
				break;
		case 4: toString = "Current card is " + card + "Go back 8 spaces.";
				break;
		case 5: toString = "Current card is " + card + "Go forward 2 spaces.";
				break;
		case 6: toString = "Current card is " + card + "Go forward 1 space.";
				break;
		case 7: toString  = "Current card is " + card + "Go forward 3 spaces.";
				break;
		case 8: toString = "Current card is " + card + "Go back to space 0.";
				break;
		case 9: toString = "Current card is " + card + "Go back 4 spaces.";
				break;
		case 10: toString  = "Current card is " + card + "Go forward 6 spaces.";
				break;
		}
		return toString;
		
	}
}
