//**************************************************************************************
//Assignment #1
//Written by: Jordan Hubscher, ID: 7019696
//For Comp 249 Section SA -Winter 2014
//**************************************************************************************

/* This program will be a simulated board-game. It will take into account how many players are playing (no less
 * than 2 and no more than 4) and what mode the users choose to play in (regular mode or debugging mode). Each player on his 
 * turn must roll two dice will determine which spot on the board he shall move to. When landing on certain spots on the 
 * board, the player will reach an obstacle and must either choose a card from the Deck of Fortune, or spin the 
 * Wheel of Fortune (in which either will determine a condition for the respective player). Whichever player surpasses or 
 * reaches the final place on the board wins. Also, if two players reach the same spot within the same turn, there is a tie.
*/

/**
 * 
 * @author Jordan Hubscher
 * @version 1.0
 * @see SpartanDriver
 * @see GameBoard
 * @see Player
 * @see DeckOfFortune
 * @see WheelOfFortune
 *
 */

import java.util.Random;

public class Dice {
	
	Random generator = new Random();
	private int number1;
	private int number2;
	
	public Dice(){
		number1 = 1;
		number2 = 1;
	}

	/**
	 * This method rolls the dice being used by the players on the gameboard to determine their next location on the board.
	 */
	public void Roll(){	
		number1 = generator.nextInt(6) + 1;
		number2 = generator.nextInt(6) + 1;
	}

	/**
	 * This method returns the number rolled on the first die.
	 * @return Returns integer value of first die rolled.
	 */
	public int getNumber1(){
		return number1;
	}
	
	/**
	 * This method returns the number rolled on the second die.
	 * @return Returns integer value of second die rolled.
	 */
	public int getNumber2(){
		return number2;
	}
	
	/**
	 * This method compares another object of type Dice to the original calling object to see if each die rolled the same value.
	 * @param other Another object of type Dice.
	 * @return Returns boolean value stating whether the two objects are equal or not.
	 */
	public boolean equals(Dice other){
		return (number1 == other.getNumber1() && number2 == other.getNumber2());
	}
	
	/**
	 * This method retuns the formatted string displaying the instance variables of each die within each object of Dice created.
	 * @return Returns each dice value in String form. 
	 */
	public String toString(){
		return "You rolled a " + number1 + " and a " + number2 + ". ";
	}
	
}
