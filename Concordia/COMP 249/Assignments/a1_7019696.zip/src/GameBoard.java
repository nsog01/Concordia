//**************************************************************************************
//Assignment #1
//Written by: Jordan Hubscher, ID: 7019696
//For Comp 249 Section SA -Winter 2014
//**************************************************************************************

/* This program will be a simulated board-game. It will take into account how many players are playing (no less
 * than 2 and no more than 4) and what mode the users choose to play in (regular mode or debugging mode). Each player on his 
 * turn must roll two dice will determine which spot on the board he shall move to. When landing on certain spots on the 
 * board, the player will reach an obstacle and must either choose a card from the Deck of Fortune, or spin the 
 * Wheel of Fortune (in which either will determine a condition for the respective player). Whichever player surpasses or 
 * reaches the final place on the board wins. Also, if two players reach the same spot within the same turn, there is a tie.
*/

/**
 * 
 * @author Jordan Hubscher
 * @version 1.0
 * @see SpartanDriver
 * @see Dice
 * @see Player
 * @see DeckOfFortune
 * @see WheelOfFortune
 *
 */
public class GameBoard 
{
	private Player[] players;//the array of players that are participating.
	
	private String[] top_rows = new String[90];//rows that will represent players location.
	
	private String[] special_rows = new String[90];//rows that will represent which location is an obstacle or not.

	private Dice die = new Dice();	//dice that will roll to determine players' new positions.
	
	private DeckOfFortune deck = new DeckOfFortune();//deck of cards that players will pick from.
	
	private WheelOfFortune wheel = new WheelOfFortune();//wheel players will spin.
	
	
	
	
	public GameBoard(int num_players){
		
		players = new Player[num_players];
		for(int i = 0; i < players.length; i++){
			players[i] = new Player();
		}
		//for loops for the arrays that constitute the gameboard.
		for(int i = 0; i < top_rows.length; i++)//for loop that will represent the locations on the gameboard.
		{
			top_rows[i] = "-";
		}
				
		for(int j = 0; j < special_rows.length; j++)//for loop for first row of special locations on gameboard.
		{
			switch(j)//switch case assignment which locations for the first thirty are obstacles.
			{
				case 9: special_rows[j] = "d";//player must pick a card from the Deck of Fortune.
					break;
				case 16: special_rows[j] = "?";//player can choose to either pick a card from the deck or spin the wheel.
					 break;
				case 19: special_rows[j] = "S";//shortcut to location 68.
					break;
				case 29: special_rows[j] = "d";
					 break;
				case 36: special_rows[j] = "?";
					break;
				case 39: special_rows[j] = "w";//player must spin the Wheel of Fortune.
					 break;
				case 49: special_rows[j] = "d";
					break;
				case 54: special_rows[j] = "S";
					 break;
				case 56: special_rows[j] = "?";
					 break;
				case 59: special_rows[j] = "w";
					break;	 
				case 69: special_rows[j] = "d";
					break;
				case 79: special_rows[j] = "w";
					break;
				default: special_rows[j] = " ";//default space.
					break;
			}
		}
	}
	
	/**
	 * This overrides the toString method to return class information rather than it's reference type.
	 * @return formatted string representation of class variables.
	 * 	
	 */
	public String toString(){
		String output = "";

			for(int i = 0; i < 3; i++){
				for(int j = 0; j < 30; j++){
					
					//this nested for loop and switch statement will
						for(int n = 0; n < players.length; n++){
							
							switch(top_rows[(i*30) + j]){
								case "-": if(players[n].getPosition() == ((i*30) + j)) top_rows[(i*30) + j] = "1";
										  if (players[n].getPosition() > 89) top_rows[89] = "1";
									break;
								case "1": if(players[n].getPosition() == ((i*30) + j)) top_rows[(i*30) + j] = "2";
										  if (players[n].getPosition() > 89) top_rows[89] = "2";
									break;
								case "2": if(players[n].getPosition() == ((i*30) + j)) top_rows[(i*30) + j] = "3";
										  if (players[n].getPosition() > 89) top_rows[89] = "3";
									break;
								case "3": if(players[n].getPosition() == ((i*30) + j)) top_rows[(i*30) + j] = "4";
										  if (players[n].getPosition() > 89) top_rows[89] = "4";
									break;
							}
						}
						output += top_rows[(i*30) + j];
						top_rows[(i*30) + j] = "-";
					}
				
				output += "\n";
				
				for(int j = 0; j < 30; j++){
					 output += special_rows[(i*30) + j];
				}
				output += "\n";
			}
		return output;
	}
	
	/**
	 * This method returns a deep copy of the array of players participating in the race.
	 * @return array of type Player.
	 */
	public Player[] getPlayer(){
		Player[] temp = new Player[players.length];
		for (int i = 0; i < temp.length; i++){
			temp[i] = players[i];
		}
		return temp;
	}
	
	/**
	 * This method returns the die being used to determine the players' next location. 
	 * @return object of type Dice.
	 */
	public Dice getDie(){
		return die;
	}
	
	/**
	 * This method returns the deck of cards being used at specific locations to re-distribute players locations.
	 * @return object of type DeckOfFortune.
	 */
	public DeckOfFortune getDeck(){
		return deck;
	}
	
	/**
	 * This method returns the wheel to be spun at specific locations to redistribute players locations.
	 * @return
	 */
	public WheelOfFortune getWheel(){
		return wheel;
	}
	
	
}
