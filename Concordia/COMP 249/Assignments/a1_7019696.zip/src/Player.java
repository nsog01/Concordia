//**************************************************************************************
//Assignment #1
//Written by: Jordan Hubscher, ID: 7019696
//For Comp 249 Section SA -Winter 2014
//**************************************************************************************

/* This program will be a simulated board-game. It will take into account how many players are playing (no less
 * than 2 and no more than 4) and what mode the users choose to play in (regular mode or debugging mode). Each player on his 
 * turn must roll two dice will determine which spot on the board he shall move to. When landing on certain spots on the 
 * board, the player will reach an obstacle and must either choose a card from the Deck of Fortune, or spin the 
 * Wheel of Fortune (in which either will determine a condition for the respective player). Whichever player surpasses or 
 * reaches the final place on the board wins. Also, if two players reach the same spot within the same turn, there is a tie.
*/

/**
 * 
 * @author Jordan Hubscher
 * @version 1.0
 * @see SpartanDriver
 * @see Dice
 * @see GameBoard
 * @see DeckOfFortune
 * @see WheelOfFortune
 *
 */

import java.util.Scanner;

public class Player {
	
	Scanner user = new Scanner(System.in);
	private String name;
	private int position;
	private boolean win ; 
	
	public Player(){
		name = "";
		position = 0;
		win = false;
	}
	
	/**
	 * This method returns the boolean attribute of the given Player object. It states whether the given Player has reached or surpassed 
	 * the final location on the gameboard.
	 * @return Returns boolean value.
	 */
	public boolean getWin(){
		return win;
	}
	
	/**
	 * This method sets the boolean attribute of the given Player object.
	 * @param win is the boolean value passed to the calling object to be set.
	 */
	public void setWin(boolean win){
		this.win = win;
	}
	
	/**
	 * This method passes an integer value to the calling object which will replace that player's current location with that of the passed integer. Used in de-bug mode.
	 * @param go Integer value replacing given player's current location.
	 */
	public void goTo(int go){
		if(go < 90 && go >= 0)
			this.position = go;
		else if(go >= 90) {
			this.position = 89;
		}
		else {
			System.out.println("ERROR! Out of bounds position.");
			System.exit(0);
		}
	}
	
	/**
	 * This method sets the given player's name to the passed String value into the calling object's name attribute.
	 * @param name String value setting the given player's name.
	 */
	public void setName(String name){
		this.name = name;
	}
	
	/**
	 * This method sets the given player's position with the passed integer value. Similar to the goTo method.
	 * @param position Integer value passed to replace given player's current position.
	 */
	public void setPosition(int position){
		this.position = position;
	}
	
	/**
	 * This method accesses the calling object's name attribute.
	 * @return Returns String value, being the calling object's name attribute.
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * This method accesses the calling object's position attribute.
	 * @return Returns integer value, being the calling object's position attribute.
	 */
	public int getPosition(){
		return position;
	}
	
	/**
	 * This method compares the passed parameter object's instance variables to the calling object's instance variables and determines whether they are equal.
	 * @param random Another object of type Player.
	 * @return Returns boolean value determining whether the calling object matches the passed object.
	 */
	public boolean equals(Player random){
		return (this.position == random.getPosition());
	}
	
	/**
	 * Overrides toString method to return a formatted string of the calling object's instance variables.
	 * @returns Formatted string displaying calling object's information/attributes.
	 */
	public String toString(){
		return "At location " + position + ".";
	}

}
