//**************************************************************************************
//Assignment #1
//Written by: Jordan Hubscher, ID: 7019696
//For Comp 249 Section SA -Winter 2014
//**************************************************************************************

/* This program will be a simulated board-game. It will take into account how many players are playing (no less
 * than 2 and no more than 4) and what mode the users choose to play in (regular mode or debugging mode). Each player on his 
 * turn must roll two dice will determine which spot on the board he shall move to. When landing on certain spots on the 
 * board, the player will reach an obstacle and must either choose a card from the Deck of Fortune, or spin the 
 * Wheel of Fortune (in which either will determine a condition for the respective player). Whichever player surpasses or 
 * reaches the final place on the board wins. Also, if two players reach the same spot within the same turn, there is a tie.
*/

import java.util.Scanner;

public class SpartanDriver {

	public static void main(String[] args) {
		
		Scanner user = new Scanner(System.in);
		int num_players = 0;//how many players there are.
		boolean okay = false;//while loop switch activator.
		boolean debug = false;//de-bug mode while loop switch activator.
		boolean regular = false;//regular mode while loop switch activator.
		int roll_die = 0;
		int new_position = 0;
		int num_winners = 0;//how many player(s) won the game.

		String welcome = "\nWelcome combatants and competitors to the Spartan Race!"
				+ "\nSurvive the obstacles if you can...ready...set...GO! MUWAHAHAHAAAA!!!";
		
		System.out.println("Spartan Race!\nv.1.0");//starting screen banner.
		System.out.println("---------------------");
		
		while (!okay){
			System.out.print("\nPlease enter the number of participants.\nThere must be at least 2 and no more than 4: ");
			
			num_players = user.nextInt();//user is prompted to enter number of those playing between 2 and 4 players.
			
			if (num_players < 2 || num_players > 4)
				
					System.out.println("\nERROR! Invalid number of players, please re-enter input.");		
			else okay = true;
		}
		
		okay = false; //reset variable after exiting loop.
		
		GameBoard board = new GameBoard(num_players);//array of players is created in order to keep track of turns, etc.
		
		for(int i = 0; i < board.getPlayer().length; i++)
		{
			board.getPlayer()[i] = new Player();
		}
		
		for(int i = 0; i < board.getPlayer().length; i++)//for loop setting the names of each player (by prompting user).
		{
			System.out.print("What is your name, Player " + (i + 1) + "?: ");
			String fix = user.nextLine();//prevent cut off from previous line.
			String name = user.next();
			board.getPlayer()[i].setName(name);
		}
		
		while(!okay){ //mode selection option for game.
			System.out.print("\nDe-bug mode or Regular mode?\n(Type in a \"0\" for regular mode and a \"1\" for De-bug mode.): ");
			int mode = user.nextInt();
			if(mode == 0){
				regular = true;
				okay = true;
			}
			else if(mode == 1){
				debug = true;
				okay = true;
			}
			else System.out.println("\nERROR! Invalid input, please re-enter value.");//error message if the player inputs invalid input 
		}
		
		okay = false; //reset variable after exiting loop.
		System.out.println(welcome); //welcome message beginning of game.
		
		while(!okay){//main while loop 1.
		
		while(!okay){//main while loop 2.
		//making sure after all players roll and after the board is printed that the game is ready for as many other turns to determine the winner.
			
			for(int i = 0; i < board.getPlayer().length; i++)
			{
				if(regular){
					while(!okay){
					
						System.out.print("\n\nPlayer " + board.getPlayer()[i].getName() + " - Enter a " + (i+1) + " to roll the dice: ");
						roll_die = user.nextInt();//player inputs number according to his turn in order to roll the die.				
			
						if(roll_die != (i+1)){
							System.out.print("\nERROR! Invalid input, re-enter value");
							continue;
						}					
						else okay = true;//done activating roll integer, time to exit loop.
					}	
				
				okay = false;//re-setting so it wont exit outer while loop.
			
				board.getDie().Roll();//rolls die.
				System.out.print(board.getDie());
				board.getPlayer()[i].setPosition(board.getPlayer()[i].getPosition() + board.getDie().getNumber1() + board.getDie().getNumber2());	
				//this statement/equation is adding the two new dice roll numbers to the previous position of the given player, by accessing
				//the dice object attribute in the GameBoard class and then adding their individual rolls.
				System.out.print(board.getPlayer()[i]);
				System.out.println("");
				}
				
				if(debug){//de-bug mode loop (will use the goTo() method as opposed to using the randomized dice roll to change players positions).
					System.out.print("\n\nPlayer " + board.getPlayer()[i].getName() + ". Please enter desired location on board: ");
					int go = user.nextInt();
				
					board.getPlayer()[i].goTo(go);	
					System.out.print(board.getPlayer()[i]);		
					System.out.println("");	
				}
			
			//evaluating whether the player is on deck of fortune locations on the board.
			if(board.getPlayer()[i].getPosition() == 9 || board.getPlayer()[i].getPosition() == 29 || board.getPlayer()[i].getPosition() == 49 
					|| board.getPlayer()[i].getPosition() == 69)
			{
				new_position = board.getDeck().pickCard(board.getPlayer()[i].getPosition());
				board.getPlayer()[i].setPosition(new_position);
				new_position = 0;
				System.out.print(" " + board.getPlayer()[i]);
			}
			//evaluating whether the player is on wheel of fortune locations on the board. 
			if(board.getPlayer()[i].getPosition() == 39 || board.getPlayer()[i].getPosition() == 59 || board.getPlayer()[i].getPosition() == 79 ){
				new_position = board.getWheel().spin(board.getPlayer()[i].getPosition());
				board.getPlayer()[i].setPosition(new_position);
				new_position = 0;
				System.out.print(" " + board.getPlayer()[i]);
			}
			
			while(!okay){
			//evaluating whether the player is on choice locations(choose to spin the wheel or draw a card) on the board. 
			if(board.getPlayer()[i].getPosition() == 16 || board.getPlayer()[i].getPosition() == 36 || board.getPlayer()[i].getPosition() == 56){
				System.out.println("Choice location; enter a \"0\" to draw a card and a \"1\" to spin the wheel: ");
				int choose = user.nextInt();	
				
					if(choose == 0){//inputting player's position for card choice.
						new_position = board.getDeck().pickCard(board.getPlayer()[i].getPosition());
						board.getPlayer()[i].setPosition(new_position);
						new_position = 0;
						System.out.print(" " + board.getPlayer()[i]);
						okay = true;
					}
					else if(choose == 1){//inputting player's position for wheel choice.
						new_position = board.getWheel().spin(board.getPlayer()[i].getPosition());
						board.getPlayer()[i].setPosition(new_position);
						new_position = 0;
						System.out.print(" " + board.getPlayer()[i]);
						okay = true;
					}
					else System.out.println("\nERROR! Invalid input, re-enter value: ");
				}
			else okay = true;
			}
				okay = false;//re-setting boolean in order to not escape outer while loop. 
			
			//shortcut to location 68.
			if(board.getPlayer()[i].getPosition() == 19 || board.getPlayer()[i].getPosition() == 54){
				System.out.print("Shortcut to location 68.");
				board.getPlayer()[i].setPosition(68);
			}
			
			if(board.getPlayer()[i].getPosition() >= 89){//determining which players have won.
				board.getPlayer()[i].setWin(true);
				num_winners++;
			}
			System.out.println("");	
			
			}//end of for loop
			System.out.print(board);
			
			if(num_winners > 0) okay = true;
		}//end of main while loop 2.
		
		okay = false;//reset value for last time, in order to ask if they wish to play another match.
		
		System.out.println("\nGAME END! We have " + num_winners + " winners! Congratulations; ");
			for(int k = 0; k < board.getPlayer().length; k++){
			if(board.getPlayer()[k].getWin()){
				System.out.println(board.getPlayer()[k].getName());
				}
			}
		
		while(!okay){
		System.out.println("\nDo you wish to play another match? Type \"yes\" to continue and \"no\" to exit: ");
		String cont = user.next();
		
			if(cont.equalsIgnoreCase("yes")){
				okay = true;
			}
			else if(cont.equalsIgnoreCase("no")){
				okay = true;
				System.exit(0);
			}
			else System.out.println("ERROR! Re-enter request.");
		}
		
		okay = false;
			
		}//end of main while loop 1.	
	}
}

	
	

			



