//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************
import java.util.InputMismatchException;
import java.io.EOFException;
/**
 * @author Jordan Hubscher
 * @version 2
 * @see GameBoard
 */

abstract public class Cell {
	
	private int playerCount;//determines how many players are on a given cell at any time.
	private String placeHolder;//the placeholder string in the visual representation of the gameboard.
	private String cellType;//the string representing what type of cell it is. 
	
	/**
	 * Constructor passing string of cell type to initiate it for the given created child cell. 
	 * @param cellType
	 */
	public Cell(String cellType)
	{
		this.cellType = cellType;
		playerCount = 0;
		placeHolder = "_";
	}
	
	/**
	 * Increments playerCount variable.
	 */
	public void updatePlayerCount(){
		playerCount++;
	}
	
	/**
	 * Decrements playerCount variable.
	 */
	public void playerLeft(){
		playerCount--;
	}
	
	/**
	 * Accessor method for cellType variable.
	 * @return String value representing what type of cell it is.
	 */
	public String getCellType(){
		return cellType;
	}
	
	/**
	 * Accessor method for placeHolder variable.
	 * @return String value representing how many players are on a given cell. If none are, it is an "_" underscore.
	 */
	public String getPlaceHolder(){
		switch(playerCount)
		{
			case 1: return placeHolder = "1";
			case 2: return placeHolder = "2";
			case 3: return placeHolder = "3";
			case 4: return placeHolder = "4";
		}
		
		return "_";	
	}
	
	/**
	 * Mutator method for placeHolder variable.
	 * @param placeHolder Passes string value of desired placeHolder value.
	 */
	public void setPlaceHolder(String placeHolder)
	{
		this.placeHolder = placeHolder;
	}
	
	abstract public void action(Player object) throws InputMismatchException,EOFException;
	abstract public void updateEnergy(Player object, int decrease);
	abstract public String displayCode();
	
}
