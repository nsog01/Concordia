//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see GameBoard, Driver, Cell
 */

import java.util.Random;

public class DeckOfFortune {

	private static int nextCard;
	
	/** Default constructor
	 * 	Sets the top card to a number between 0 and 9
	 */
	public DeckOfFortune()
	{
		Random randomGenerator = new Random();
		nextCard = randomGenerator.nextInt(10);
	}
	
	/** Accessor method
	 * @return	nextCard 	the number of the next card
	 */
	public static int getNextCard()
	{
		return nextCard + 1;
	}
	
	public static int pickCard(int location)
	{
		switch(nextCard+1)
		{
		case 1: location -= 9;
			Driver.Execute("Go back 9. ",true);
			break;
		case 2: location = 0;
			Driver.Execute("Go back to the beginning. ",true);
			break;
		case 3: location -= 3;
			Driver.Execute("Go back 3. ",true);
			break;
		case 4: location -= 8;
			Driver.Execute("Go back 8. ",true);
			break;
		case 5: location += 2;
			Driver.Execute("Go forward 2. ",true);
			break;
		case 6: location += 1;
			Driver.Execute("Go forward 1. ",true);
			break;
		case 7: location += 3;
			Driver.Execute("Go forward 3. ",true);
			break;
		case 8: location = 0;
			Driver.Execute("Go back to the beginning. ",true);
			break;
		case 9: location -= 4;
			Driver.Execute("Go back 4. ",true);
			break;
		case 10: location += 3;
			Driver.Execute("Go forward 3. ",true);
			break;
		} // switch
		Driver.Execute("You are at location " + location + ".\n",true);
		
		// Prepare for next turn
		nextCard = (++nextCard % 10);
		
		return location;	
	}// method pickCard

}
