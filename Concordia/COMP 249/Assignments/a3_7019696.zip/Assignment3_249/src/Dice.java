//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see Driver
 */

import java.util.Random;

public class Dice
{

	// Instance Variable
	private int die1;
	private int die2;

	public Dice ()
	{
		die1 = 0;
		die2 = 0;
	}

	/**
	 * Simulates the rolling of 2 die by generating 2 random numbers
	 * between 1 and 6 inclusive.
	 * @return Sum of the 2 die
	 */	
	public int rollDice()
	{
		Random randomGenerator = new Random();
		die1 = randomGenerator.nextInt(6) + 1;
		die2 = randomGenerator.nextInt(6) + 1;
		return die1 + die2;
	}
	
	public int getDie1()
	{
		return die1;
	}
	
	public int getDie2()
	{
		return die2;
	}
	
	public void setDie1(int die1) throws DieOutOfBoundsException
	{
		if(die1 > 6 || die1 < 1)
			throw new DieOutOfBoundsException();
		this.die1 = die1;
	}
	
	public void setDie2(int die2) throws DieOutOfBoundsException
	{
		if(die2 > 6 || die2 < 1)
			throw new DieOutOfBoundsException();
		this.die2 = die2;
	}
	
	/** 
	 *Returns a string representation of the object. 
	 */
	public String toString()
	{
		return "You rolled a "+ die1 + " and a " + die2 + ".";
	}

}
