
public class DieOutOfBoundsException extends Exception{

	public DieOutOfBoundsException()
	{
		super();
	}
	
	public DieOutOfBoundsException(String message)
	{
		super(message);
	}

}
