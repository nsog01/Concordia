//**************************************************************************************
//Assignment #3
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//Due: March 21st, 2014
//**************************************************************************************

/* This program simulates a game called Spartan Race.  
 * Spartan Race is a type of obstacle race where all players start with differing positions and energy 
 * levels based on their player type, and must run on a course where various obstacles are hidden.  
 * The player who arrives at the finish line first, or survives the longest,  wins the race.
 * While the others were sold as slaves.  
 */

import java.util.*;	// for keyboard input
import java.io.*;  //to handle all the different exceptions that may occur.

public class Driver {
	
	//Static Variable declaration
	static Scanner input;
	static PrintWriter output;
	static Scanner fileScan;
	static boolean testMode;
	static Player [] players;
	static File race_out;

	public static void main(String[] args)
	{	
		input = new Scanner(System.in);//initializing input Scanner.

		// Variable declaration
		GameBoard board = new GameBoard();
		Cell[] track = board.getTrack();//copied array of cells from gameboard.
		Dice dice = new Dice();
		DeckOfFortune deck = new DeckOfFortune();
		WheelOfFortune wheel = new WheelOfFortune();
	
		int whoseTurn = 0, roll = 0, numOfWinners = 0, playAgain = 0, die1 = 0, die2 = 0;
		String EOF = "", outputHolder = ""; 
		boolean reported = false; //prevents winners report from repeating
		

		
		while(testMode == false)
		{
			try{
				race_out = new File("race_out.txt");
				System.out.println("Writing to: " + race_out.getPath() + "\n");
				output = new PrintWriter(new FileOutputStream(race_out));
				//Welcome message
				Execute("Spartan Race - Version 3.0\n-----------------------------------\n",true);
				do{
					// Regular or test mode?
					Execute("\nTest Mode? (Enter 1 for debug mode and anything else for real-time mode): ", true);
					int user = input.nextInt();
					testMode = (user == 1);
					players = setUpRacers();

					//And the race is on!!!
					Execute( "\nWelcome racers ... and prepare for the milestones ahead ... MUWAHAHAHAAA!!!!\n\n" +
							"On your mark ...  Get set  ... Go!",true);
					do
					{
						for(int i = 0; i < players.length; i++)//Each player moves
						{		
							while (whoseTurn != (i+1) && players[i].getDead() == false)
							{
								Execute("\nCurrent Position: " + players[i].getPosition() + ", Current Energy level: " 
										+ players[i].getEnergy(),true);
								if(testMode)
									break;
								Execute("\nPlayer " + players[i].getName()+ "  - Enter a " + (i+1) + " to roll the dice: ",true);
								whoseTurn = input.nextInt();//input player number to roll dice.
								Execute("\n",true);
							}

							track[players[i].getPosition()].playerLeft();//player leaves previous spot and moves to new spot.
							if(testMode)
							{
								Execute("Player " + players[i].getName()+ "  - Enter value for Die 1: ",true);
								if(fileScan.hasNextInt())
								{
									die1 = fileScan.nextInt();
									Execute(die1 + ". ",true);
									dice.setDie1(die1);
								}
								else if(die1 == 0 || die1 > 6 || die1 < 1)//making sure it throws an exception if the needed die value wasn't checked .
								{
									System.err.print("Invalid die input");
									throw new DieOutOfBoundsException();
								}

								Execute("\nEnter value for Die 2: ",true);
								if(fileScan.hasNextInt())
								{
									die2 = fileScan.nextInt();
									Execute(die2 + ". ",true);
									dice.setDie2(die2);
								}
								else if(die2 == 0 || die2 > 6 || die2 < 1)
								{
									System.err.print("Invalid die input");
									throw new DieOutOfBoundsException();
								}

								roll = (dice.getDie1() + dice.getDie2());//combined die values to advance by
								if((players[i].getPosition() + roll) > 89)//prevent ArrayIndexOutOfBoundsException
								{
									//calculate difference from players current position to last location on board
									roll = 89 - players[i].getPosition();
									players[i].setPosition(89);//set location to last position (hence not going out of bounds)

									track[players[i].getPosition()].updateEnergy(players[i], roll);//update energy based on calculated difference
								}	
								else
									players[i].advanceBy(roll);//otherwise, advance by the combined roll of both dice
								track[players[i].getPosition()].updateEnergy(players[i], roll);

								if(fileScan.hasNext())//if it reaches a character when not on a special cell, ignore it
									fileScan.next();
								else if((EOF = fileScan.next()) == null)
								{
									throw new EOFException();
								}
							}
							else
							{
								roll = dice.rollDice();
								Execute(dice.toString(),true);
								track[players[i].getPosition()].updateEnergy(players[i], roll);
								System.out.println(" Energy level: " + players[i].getEnergy());
								players[i].advanceBy(roll);	
							}

							System.out.print(" At location " + players[i].getPosition() + ".\n");

							//Has racer landed on a special location?				
							switch(board.getCode(players[i],players[i].getPosition()))
							{
							case "d": 
								track[players[i].getPosition()].action(players[i]);//performs action, "teleports" to new spot without using energy.
								track[players[i].getPosition()].action(players[i]);//then updates playerCount for its new spot for the gameboard.
								break;
							case "s":
								track[players[i].getPosition()].action(players[i]);
								track[players[i].getPosition()].action(players[i]);
								break;
							case "w": 
								track[players[i].getPosition()].action(players[i]);
								track[players[i].getPosition()].action(players[i]);
								break;
							case "?": 
								track[players[i].getPosition()].action(players[i]);
								track[players[i].getPosition()].action(players[i]);
								break;
							case " ":
								track[players[i].getPosition()].action(players[i]);
								break;						
							}

							Execute("Keep playing.\n",true);	
						}

						Execute(board.toString(),false); // Display board

						//Any winners?
						numOfWinners = 0;
						for (int i = 0; i < players.length; i++)
						{
							if (players[i].getPosition() >= 89)
								numOfWinners++;
							else if (players[i].getEnergy() <= 0)
								players[i].setDead(true);
						}

						die1 = 0; die2 = 0; //reset die values so it may throw exception

					}while (numOfWinners == 0);

					// And the winner(s) is/are	
					winnersReport(numOfWinners, players);

					playAgain = playAgain();  // Does the user want to play again?

					if(playAgain == 1)
					{
						board.resetTrack(track); // set playerCount of each cell back to 0 => "_".
						reported = true;
					}
					else
						System.exit(0);
				} while (playAgain == 1);
			}
			catch(FileNotFoundException e)
			{
				System.err.println("FileNotFound:\n" 
						+ "For for real-time mode; file \'race_out.txt\' could not be found/written to.\n\n"
						+ "For De-bug mode; \'debug_input.txt\' cannot be found/read from.\n"
						+ "Please create a new instance of the File class with the name \'debug_input.txt\'.\n"
						+ "Specify in order the following:\n"
						+ "-The number of players\n"
						+ "-Name of player #1\n"
						+ "-Name of player #2\n"
						+ "-Type of player #1\n"
						+ "-Type of player #2\n"
						+ "-Specify the moves of the players in the following fashion:\n"
						+ "\tdievalue1 dievalue2 jokerchoice"
						+ "\nExiting Program");
				System.exit(0);
			}
			catch(InputMismatchException e)
			{
				System.err.println("\nInputMismatchException: Put in different input/data type than that being asked.");
				System.exit(0);
			}
			catch(NullPointerException e)
			{
				System.err.println("NullPointerException: welp...ya done goofed...");
				if(testMode == false)
				{
					System.err.println("Re-starting program");
					break;
				}
					System.exit(0);
			}
			catch(PlayerTypeOutOfBoundsException e)
			{
				System.err.println("\nPlayerTypeOutOfBoundsException: That player type does not exist.");
				if(testMode == false)
				{
					System.err.println("Re-starting program");
					break;
				}
					System.exit(0);
			}
			catch(DieOutOfBoundsException e)
			{
				System.err.println("\nDieOutOfBoundsException: Inputted value greater than 6 or less than 1 for one of the two die,"
						+ "\n\tOr the value for one or more die was skipped");
				if(testMode == false)
				{
					System.err.println("Re-starting program");
					break;
				}
					System.exit(0);
			}
			catch(NoSuchElementException e)
			{
				System.err.println("NoSuchElementException: End of file reached.");
				if(testMode == false)
				{
					System.err.println("Re-starting program");
					break;
				}
					System.exit(0);
			}
			catch(EOFException e)
			{
				System.err.println("EOFException: End of file reached.");
				if(testMode == false)
				{
					System.err.println("Re-starting program");
					break;
				}
					System.exit(0);
			}
			catch(IOException e)
			{
				System.err.println("IOException: trouble with either the used scanner or files...");
				System.exit(0);
			}
			catch(Exception e)
			{
				System.err.println("Exception: general exception...tsk, tsk...");
				System.exit(0);
			}
			finally
			{	
				//Any winners?
				if(!reported)
				{
					numOfWinners = 0;
					for (int i = 0; i < players.length; i++)
					{
						if (players[i].getPosition() >= 89)
							numOfWinners++;
						else if (players[i].getEnergy() <= 0)
							players[i].setDead(true);
					}
				}
				// Closing message
				Execute("\n-->  Hope you enjoyed Version 3.0 of the Spartan Race game!  <--\n",true); 
				input.close(); //closing Scanner/FileInputStream
				output.close();
				fileScan.close();
			}
		}
	}// end of main()


	
	
	// Static methods
	//---------------

	public static Player[] setUpRacers() throws PlayerTypeOutOfBoundsException,FileNotFoundException,InputMismatchException
	{
		boolean done = false;
		int playerType;
		int numOfRacers;
		String name;
		
		Player [] players = new Player[0];//Get name of players and create Racer objects
		do
		{
			Execute("How many racers will there be (2 to 4)? ",true);

			if(testMode)//static reference to testMode to determine whether to read from input file or not.
			{
				fileScan = new Scanner(new FileInputStream("debug_input.txt"));
				numOfRacers = fileScan.nextInt();
				Execute(numOfRacers + "\n",true);
			}
			else 
				numOfRacers = input.nextInt();
				Execute(numOfRacers + "",false);

			if (numOfRacers < 2 || numOfRacers > 4)// How many racers?
			{
				System.out.print(numOfRacers + " racer(s) is not possible. The track can accommodate 2 to 4 players only.\n" +
						"So, how many racers?: ");
			}
			else
				players = new Player[numOfRacers];// Creating an array of specified number of players.

		} while (numOfRacers < 2 || numOfRacers > 4);

		for (int i = 0; i < numOfRacers; i++)
		{
			if(testMode)
			{
				//this way stores the player name and type so it can ask the questions in reverse order.
				Execute("Name of Player #" + (i + 1) + ": ",true);
				name = fileScan.next();
				Execute(name + "\n",false);
				Execute("Choose Archetype, Player #" + (i + 1) + 
						"\n(Enter 1 for Spartiate, 2 for Helot, and a 3 for Periokis): ",true);
				playerType = fileScan.nextInt();
				Execute(playerType + "\n",false);
				if(playerType == 1)
					players[i] = new Spartiate(name);
				if(playerType == 2)
					players[i] = new Helot(name);
				if(playerType == 3)
					players[i] = new Periokis(name);
				else if(playerType > 3 || playerType < 1)
				{
					throw new PlayerTypeOutOfBoundsException();
				}
			}
			else
			{
				do
				{
					Execute("Choose Archetype, Player #" + (i + 1) + 
							"\n(Enter 1 for Spartiate, 2 for Helot, and a 3 for Periokis): ",true);
					playerType = input.nextInt();
					Execute(playerType + "",false);
					if(playerType == 1 || playerType == 2 || playerType == 3)
						done = true;
				} while(!done);//stays in do while until correct player type is chosen.
				Execute("Name of Player #" + (i + 1) + ": ",true);
				name = input.next();
				Execute(name,false);
				if(playerType == 1)
					players[i] = new Spartiate(name);
				if(playerType == 2)
					players[i] = new Helot(name);
				if(playerType == 3)
					players[i] = new Periokis(name);
			}
		}

		return players;
	} // method setUpRacers

	public static int joker(int location) throws InputMismatchException,EOFException
	{
		String choice = "";
		String EOF2 = "";
		
			do
			{	//Joker cell decision; spin wheel or pick card.
				Execute("Enter \'w\' to spin the wheel or \'c\' to pick a card: ",true);
				if(testMode)
				{
					if(fileScan.hasNextInt())
					{
						fileScan.nextInt();
					}
					if(fileScan.hasNextInt())
					{
						fileScan.nextInt();
					}
					if(fileScan.hasNext())
					{
						choice = fileScan.nextLine();
						Execute(choice,true);
					}
					else if((EOF2 = fileScan.nextLine()) == null)
						throw new EOFException();
				}
				else
				{
					choice = input.nextLine();
					Execute(choice + "\n",true);
				}
			} while (choice.equals("w") || (choice.equals("c")));

			if (choice == "w")
				return WheelOfFortune.spin(location);
			
		return DeckOfFortune.pickCard(location);
	} // method joker

	public static void winnersReport(int n, Player[] players)
	{
		Execute("\n\nWe have " + n + (n > 1? " winners!":" winner!")+  //displays which players have won the round.
				"\nCongratulations to:",true);
		for (int i = 0; i < players.length; i++)
			if(players[i].getPosition() >= 89 )
				System.out.println("\t" + players[i].getName());
		
		Execute(	"\nThe rest of you will be sold as slaves! MUWAHAHAHAHAAAAA!!!!!\n",true);	
	} //method winnersReport
	
	public static int playAgain() throws InputMismatchException
	{
		int again = 0;

		Execute("Would you like to play again? (Enter 1 for yes): ",true);//determines another round.
		again = input.nextInt();
		Execute(again + "",false);
	
		return again;
	}// method playAgain
	
	static void Execute(String message, boolean bool)
	{
		if(bool)
		{
			System.out.print(message);
			output.print(message);
		}
		else
			output.print(message);
	}
	
}// class Driver