//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see Driver
 */

public class GameBoard {
	
	private Cell[] track = new Cell[90];
	
	//Constructor
	public GameBoard()
	{
		for(int i = 0; i < 90; i++)
		{
			track[i] = new RegularCELL();
		}
		track[10] = new DeckCELL();
		track[30] = new DeckCELL();
		track[50] = new DeckCELL();
		track[70] = new DeckCELL();//deck of fortune cells.
		track[20] = new SkipCELL();
		track[55] = new SkipCELL();//skip cells.
		track[40] = new WheelCELL();
		track[60] = new WheelCELL();
		track[80] = new WheelCELL();//wheel of fortune cells.
		track[17] = new JokerCELL();
		track[37] = new JokerCELL();
		track[57] = new JokerCELL();//joker cells.
	}
	
	/**
	 * Resets the count of players at each location to back to zero => and 
	 * therefore the placeHolder of each cell will become an "_" underscore. 
	 */
	public void resetTrack(Cell[] track)
	{
		for(int i = 0; i < track.length; i++)
		track[i].setPlaceHolder("_");
	}
	
	/**
	 * Accessor method for the game board.
	 * @return reference to a copy of the original array of cells.
	 */
	public Cell[] getTrack(){
		
		Cell[] temp = new Cell[90];
		for(int i = 0; i < 90; i++)
		{
			temp[i] = track[i]; 
		}
		temp[10] = track[10];
		temp[30] = track[30];
		temp[50] = track[50];
		temp[70] = track[70];
		temp[20] = track[20];
		temp[55] = track[55];
		temp[40] = track[40];
		temp[60] = track[60];
		temp[80] = track[80];
		temp[17] = track[17];
		temp[37] = track[37];
		temp[57] = track[57];
		return temp;
	}
	
	/** 
	 * Returns the cell type of the given cell in the track (i.e. a deck cell, a wheel cell, 
	 * a joker cell, a skip cell, or a regular cell.)
	 * @param	the player who's turn it is, in order to determine which cell type of the 
	 * location on the board to return, we use this player's position on the board.
	 * @param	position location on board to evaluate
	 * @return	track[position].getCellType() the character code for the location passed
	 */
	public String getCode(Player object, int position)
	{
		if (position >= 89)
		{
			object.setPosition(89);
			return track[89].getCellType();
		}
			else 
		{	
			return track[position].getCellType();
		}
	}
	
	/** 
	 * Returns a string representation of the object.
	 * @return	
	 */
	public String toString()
	{
		String board = "\n";
		
		for(int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 30; j++)
				board += track[30*i + j].getPlaceHolder() + " ";
			board += "\n";
			
			for (int j = 0; j < 30; j++)
				board += (track[30*i + j].getCellType() + " ");
			board += "\n";
	
		}
		return board;
	}// toString()

}// class RaceTrack