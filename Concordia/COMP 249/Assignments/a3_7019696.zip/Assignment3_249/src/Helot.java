//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

public class Helot extends Player{
	
	/**
	 * Constructor passes a string representing the respective player's name.
	 * @param name String value representing given player's name.
	 */
	public Helot(String name){
		super("h_" + name);
		setEnergy(60);
		setPosition(40);
	}
}
