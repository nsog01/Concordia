//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see Cell
 */

import java.util.Scanner;
import java.util.InputMismatchException;
import java.io.EOFException;

public class JokerCELL extends Cell{
	
	public JokerCELL(){
		super("?");
	}
	
	/**
	 * Abstract method which passes the respective player in order to use his/her variables appropriately in order to update
	 * his/her current position if pick a card or spinning the wheel, or just skipping cells.
	 */
	public void action(Player object) throws InputMismatchException,EOFException
	{
		int new_position = 0;
		new_position = Driver.joker(object.getPosition());
		object.setPosition(new_position);
	}
	
	/**
	 * Abstract method which passes the respective player and the integer representing the total number from the roll of the dice
	 * in order to subtract from his/her energy pool.
	 */
	public void updateEnergy(Player object, int decrease){
		int updated = 0;
		if((object.getEnergy() - decrease) <= 0)
			{
				updated = 0;
				object.setDead(true);
			}
		updated = object.getEnergy() - decrease;
		object.setEnergy(updated);
	}
	
	/**
	 * Returns cell type of the given cell.
	 * @return String value representing the given cell's type.
	 */
	public String displayCode(){
		return getCellType();
	}
	
	public String toString(){
		return displayCode();
	}
}
