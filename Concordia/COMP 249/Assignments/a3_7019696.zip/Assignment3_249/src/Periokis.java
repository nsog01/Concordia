//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see Cell
 */

public class Periokis extends Player{
	
	/**
	 * Constructor passes a string representing the respective player's name.
	 * @param name String value representing given player's name.
	 */
	public Periokis(String name){
		super("p_" + name);
		setEnergy(130);
		setPosition(0);
	}
}
