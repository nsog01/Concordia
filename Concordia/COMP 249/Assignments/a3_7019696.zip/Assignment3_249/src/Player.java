//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see Driver
 */

public class Player {
	private String name;//player's name.
	private int position;//the player's current location.
	private int energy;//amount of energy each player has.
	private boolean dead;//determines whether players are eliminated form the game or not.

	// Constructor
	public Player()
	{}

	/** 
	 * Constructor
	 * @param name of player
	 */
	public Player(String name)
	{
		this.name = name;
		position = 0;
		energy = 0;
		dead = false;
	}
	
	/**
	 * Accessor method for elimination variable "dead".
	 * @return boolean value determining whether player is in the race or not and skips his/her turn if "true".
	 */
	public boolean getDead(){
		return dead;
	}
	
	/**
	 * Mutator method for elimination variable "dead".
	 * @param dead
	 */
	public void setDead(boolean dead){
		this.dead = dead;
	}
	
	/**
	 * Accessor method for player's energy.
	 * @return integer representing player's energy.
	 */
	public int getEnergy(){
		return energy;
	}
	
	/**
	 * Mutator method for energy instance variable.
	 * @param energy Amount of energy the given player has to expend.
	 */
	public void setEnergy(int energy){
		this.energy = energy;
	}
	
	/** 
	 * Accessor method for name instance variable.
	 * @return	name	racer's name
	 */
	public String getName()
	{
		return name;
	}
	
	/** Accessor method for position instance variable.
	 * @return	position of player
	 */
	public int getPosition()
	{
		return position;
	}
	
	/** 
	 * Mutator method for position instance variable.
	 * @param 	n location to move racer to
	 */
	public void setPosition(int n)
	{
		position = n;
	}
	
	/**
	 * Move racer by specified number of positions
	 * @param n number of positions to move racer on the board (can be >0 or <0) 
	 */
	public void advanceBy(int n)
	{
		position += n;
	}

}
