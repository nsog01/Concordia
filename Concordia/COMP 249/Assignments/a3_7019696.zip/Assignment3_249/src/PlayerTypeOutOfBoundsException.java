
public class PlayerTypeOutOfBoundsException extends Exception{
	
	public PlayerTypeOutOfBoundsException()
	{
		super();
	}

	public PlayerTypeOutOfBoundsException(String message)
	{
		super(message);
	}
}
