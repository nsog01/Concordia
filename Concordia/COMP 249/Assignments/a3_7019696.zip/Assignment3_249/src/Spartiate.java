//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see Player
 */

public class Spartiate extends Player{
	
	/**
	 * Constructor passes a string representing the respective player's name.
	 * @param name String value representing given player's name.
	 */
	public Spartiate(String name){
		super(name);
		setEnergy(100);
		setPosition(20);
	}
}
