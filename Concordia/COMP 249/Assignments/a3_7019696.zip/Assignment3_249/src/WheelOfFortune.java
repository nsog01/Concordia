//**************************************************************************************
//Assignment #2
//Written by: Jordan Hubscher, ID: 7019696
//For COMP 249 Section SA -Winter 2014
//**************************************************************************************

/**
 * @author Jordan Hubscher
 * @version 2
 * @see GameBoard, Cell, Driver
 */

public class WheelOfFortune {

	/**
	 * Simulates the spinning of the wheel of fortune. There are 
	 * 8 possible slots the wheel can stop on.
	 * @param 	location location racer at
	 * @return	new location
	 */
	public static int spin(int location)
	{
		switch((int) (Math.random()* 8 + 1))
		{
		case 1: location += 1;
		Driver.Execute("Go forward 1. ",true);
		break;
		case 2: location += 2;
		Driver.Execute("Go forward 2. ",true);
		break;
		case 3: location = 0;
		Driver.Execute("Go back to the beginning. ",true);
		break;
		case 4 : location -=4;
		Driver.Execute("Go back 4. ",true);
		break;
		case 5 : location -=6;
		Driver.Execute("Go back 6. ",true);
		break;
		case 6 : location -=7;
		Driver.Execute("Go back 7. ",true);
		break;
		case 7 : location -=8;
		Driver.Execute("Go back 8. ",true);
		break;
		case 8 : location -=9;
		Driver.Execute("Go back 9. ",true);
		break;
		}// switch
		Driver.Execute("You are now at location " + location + ".\n",true);
		return location;
	} // method spinTheWheel

}
