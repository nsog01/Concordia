//**************************************************************************************
//Assignment #4
//Author: Jordan Hubscher ID: 7019696, Francisco Guerreiro ID: 7187491
//For: COMP 249 Section SA -Winter 2014
//Due: April 11th, 2014
//**************************************************************************************

public class Gladiator {

	private String name;
	private int number;

	private Gladiator next;

	public Gladiator() {
		name = null;
		// setCount(0);
		setNumber(0);
	}

	public Gladiator(String newGladiator, Gladiator headBefore) {

		next = headBefore;
		this.name = newGladiator;
		// setCount(newCount);
	}

	public void setNext(Gladiator otherGladiator) {
		next = otherGladiator;
	}

	public Gladiator getNext() {
		return next;
	}

	public String getGladiator() {
		return name;
	}

	public String toString() {
		return name;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
}
