//**************************************************************************************
//Assignment #4
//Author: Jordan Hubscher ID: 7019696, Francisco Guerreiro ID: 7187491
//For: COMP 249 Section SA -Winter 2014
//Due: April 11th, 2014
//**************************************************************************************

import java.util.Scanner;

public class GladiatorDriver 
{
	public static void main(String[] args) {

		GladiatorList list = new GladiatorList();
		Scanner scn = new Scanner(System.in);
		System.out.println("How many Gladiators would you like to have ? ");

		int numberGlad = scn.nextInt();

		for (int i = 0; i < numberGlad; i++) {
			System.out.println("Please type name of gladiator number " + (i+1) +".");
			String name = scn.next();
			list.addToStart(name);
		}

		System.out.println("Type any key when you're ready !!!");
		scn.next();
		System.out.println("Current list of gladiators");
		list.traverseList();
		list.findThirdGladiator(list.head);
	}
}
