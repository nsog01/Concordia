//**************************************************************************************
//Assignment #4
//Author: Jordan Hubscher ID: 7019696, Francisco Guerreiro ID: 7187491
//For: COMP 249 Section SA -Winter 2014
//Due: April 11th, 2014
//**************************************************************************************

import java.util.Scanner;

public class GladiatorList {

	// ALWAYS points to the first Gladiator
	Gladiator head;
	private int gladiatorCount;
	private int lastIndexed;
	private Gladiator indexed;
	private Gladiator before;
	private Gladiator after;

	GladiatorList() {
		head = null;
		lastIndexed = 0;
	}

	public void addToStart(String name) {

		Gladiator lastGladiator = null;
		if (head != null) {
			lastGladiator = head;

			for (int i = 0; i < getGladiatorCount() - 1; i++) {
				if (lastGladiator.getNext() != null) {
					lastGladiator = lastGladiator.getNext();
				}
			}
		}

		head = new Gladiator(name, head);
		if (lastGladiator != null)
			lastGladiator.setNext(head);

		gladiatorCount++;
	}

	public void caesarSaysDie() {
		findThirdGladiator(head);

	}

	public int size() {
		int count = 0;
		Gladiator pos = head;

		while (pos != null) {
			count++;
			pos = pos.getNext();
		}
		return count;
	}

	public void traverseList() {
		Gladiator gladiator = new Gladiator();
		gladiator = head;
		for (int i = 0; i < getGladiatorCount(); i++) {
			String comma = i == getGladiatorCount() - 1 ? " " : ", ";
			System.out.print(gladiator + comma);
			gladiator = gladiator.getNext();
		}
		System.out.println();
	}

	public Gladiator findThirdGladiator(Gladiator gladiatorIndexed) {
		setIndexed(gladiatorIndexed);

		if (gladiatorCount == 1) {
			return getWinner();
		}

		// System.out.println(gladiator);
		// System.out.println(gladiator.getNext().getNext().getNext());

		Gladiator gladiatorBefore = getIndexed().getNext();
		setIndexed(gladiatorBefore.getNext());
		setLastIndexed(getLastIndexed() + 2);
		Gladiator gladiatorAfter = getIndexed().getNext();

		// setIndexed(getIndexed().getNext().getNext().getNext());
		System.out.println(getIndexed() + " is going to die.");
		// Passes the before and after to points to themselves
		removeGladiator(gladiatorBefore, gladiatorAfter, getIndexed());
		gladiatorCount--;
		System.out.println("Press any key and Enter to continue.");
		new Scanner(System.in).next();
		System.out.println("\nGladiators left in the Arena:");
		traverseList();
		System.out.println();
		// System.out.println(" Passing index " + indexed);
		findThirdGladiator(gladiatorBefore);
		return null;
		// return getIndexed();
	}

	private void removeGladiator(Gladiator before, Gladiator after,
			Gladiator indexed) {
		if (indexed.equals(head))	head = after;
		before.setNext(after);
		indexed.setNext(null);
	}

	private Gladiator findByName(String gladiatorName) {
		Gladiator gladiator = new Gladiator();
		int i = 0;
		gladiator = head;
		while (gladiatorName != gladiator.getGladiator()
				&& i <= getGladiatorCount()) {
			gladiator = gladiator.getNext();
			i++;
		}

		return gladiator;
	}

	private Gladiator getWinner() {
		System.out.println("Winner is: " + head);
		return head;
	}

	public boolean deleteFirstGladiator() {
		if (head != null) {
			head = head.getNext();
			return true;
		} else
			return false;
	}

	public int getCount() {
		return getGladiatorCount();
	}

	public void setCount(int count) {
		this.setGladiatorCount(count);
	}

	public Gladiator getIndexed() {
		return indexed;
	}

	public void setIndexed(Gladiator indexed) {
		this.indexed = indexed;
	}

	public Gladiator getAfter() {
		return after;
	}

	public void setAfter(Gladiator after) {
		this.after = after;
	}

	public Gladiator getBefore() {
		return before;
	}

	public void setBefore(Gladiator before) {
		this.before = before;
	}

	public int getLastIndexed() {
		return lastIndexed;
	}

	public void setLastIndexed(int lastIndexed) {
		this.lastIndexed = lastIndexed;
	}

	public int getGladiatorCount() {
		return gladiatorCount;
	}

	public void setGladiatorCount(int gladiatorCount) {
		this.gladiatorCount = gladiatorCount;
	}
}
