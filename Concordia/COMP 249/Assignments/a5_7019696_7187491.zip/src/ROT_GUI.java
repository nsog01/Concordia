//**************************************************************************************
//Assignment #4
//Author: Jordan Hubscher ID: 7019696, Francisco Guerreiro ID: 7187491
//For: COMP 249 Section SA -Winter 2014
//Due: April 11th, 2014
//**************************************************************************************

/*
 * This program will display a GUI giving the option to display user input test \
 * as one of a few simple encrypted counterparts (i.e. ROT 5, ROT 13, etc.) 
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ROT_GUI 
{
	public static void main(String[] args)
	{
		ROTFRAME GUI = new ROTFRAME();	
		
	}// endof#main
}
//************************************************************************************************************************
//----------------------------------------------------GUI CLASSES---------------------------------------------------------
//************************************************************************************************************************	
	class ROTFRAME extends JFrame
	{
		private String inputItem = ""; //holds input field text
		private String temp_buffer = ""; //holds encrypted input string
		private String comboItem; //holds JComboBox item for processing listener
		private int n; //factor for encryption/decryption (i.e. ROT-n)
		private boolean encryptON = true; //boolean determining whether the GUI will encrypt or decrypt given input text
		private JFrame rot_frame; //JFrame holding all Components for GUI
		private JPanel rot_panel_main; //JPanel holding both the left and right panels as well as the welcome title 
		private JPanel rot_panel_center; //JPanel holding the setting Components within the GUI frame
		private JPanel rot_panel_left; //JPanel holding input/output Components within the GUI frame
		private JPanel rot_panel_right; //JPanel holding the setting Components within the GUI frame
		private JComboBox rot_selection; //JComboBox holding the selection options for n's encrypting/decrypting factor
		private JCheckBox number_check; //JCheckBox determines whether numbers should be encrypted/decrypted
		private JRadioButton encrypt; //JRadioButton that will activate the event listener for text encrypting
		private JRadioButton decrypt; //JRadioButton that will activate the event listener for text decrypting
		private JTextField input_field; //JTextField that will take the user's input for encryption/decryption
		private JTextField output_field; //JTextField that will output the user's encrypted/decrypted text result
		private JButton go; //JButton that will chain it's event listener to that of the encryption or decryption function
		private JButton clear; //JButton that will clear the input and output text fields
		private JLabel welcome = new JLabel("<html>" + "Weclome, Spartans! \nEnter the text you wish to have encrypted"
				+ " or decrypted based on your opted selection: " + "</html>");
		
		public ROTFRAME()
		{
			rot_frame = new JFrame("ROT-n Ecryption/Decryption Cipher");
			rot_frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			//setting up all components with appropriate listeners
			rot_selection = new JComboBox(new String[]{"ROT-5","ROT-7","ROT-13","ROT-17"});
			rot_selection.setFont(new Font("Times New Roman",Font.ITALIC,12));
			rot_selection.setBackground(new Color(255,255,255));
			rot_selection.setEnabled(true);
			number_check = new JCheckBox(": CHECK NUMBERS");
			number_check.setBackground(new Color(255,200,25));
			encrypt = new JRadioButton(": ENCRYPT");
			encrypt.setBackground(new Color(255,200,25));
			encrypt.setFont(new Font("Arial",Font.BOLD,12));
			encrypt.setSelected(true);
			decrypt = new JRadioButton(": DECRYPT");
			decrypt.setFont(new Font("Arial",Font.BOLD,12));
			decrypt.setBackground(new Color(255,200,25));
			input_field = new JTextField();
			input_field.setBackground(new Color(255,255,255));
			output_field = new JTextField();
			output_field.setBackground(new Color(255,255,255));
			output_field.setEditable(false);
			go = new JButton("GO!");
			go.setFont(new Font("Times New Roman",Font.ITALIC,18));
			go.setBackground(new Color(255,255,255));
			go.addActionListener(new AListener());
			clear = new JButton("CLEAR");
			clear.setBackground(new Color(255,255,255));
			clear.setFont(new Font("Times New Roman",Font.ITALIC,18));
			clear.addActionListener(new AListener());
			
			//setting up main panel layout
			rot_panel_main = new JPanel();
			rot_panel_main.setBackground(new Color(255,255,255));
			rot_panel_main.setLayout(new GridLayout(2,1));
			rot_panel_main.add(welcome,0);
			welcome.setFont(new Font("Times New Roman",Font.ITALIC,18));
			
			//setting up center panel layout
			rot_panel_center = new JPanel();
			
			rot_panel_center.setLayout(new GridLayout(1,2));
			
			//setting up left panel layout (goes into center panel))
			rot_panel_left = new JPanel();
			rot_panel_left.setLayout(new GridLayout(4,1));
		
			//setting up right panel layout (goes into center panel)
			rot_panel_right = new JPanel();
			rot_panel_right.setLayout(new GridLayout(6,1));
			
			//adding appropriate components to left panel
			JLabel input = new JLabel("INPUT: ");
			input.setFont(new Font("Arial",Font.BOLD,12));
			input.setOpaque(true);
			input.setBackground(new Color(255,200,25));
			rot_panel_left.add(input,0);
			rot_panel_left.add(input_field,1);
			JLabel output = new JLabel("OUTPUT: ");
			output.setFont(new Font("Arial",Font.BOLD,12));
			output.setOpaque(true);
			output.setBackground(new Color(255,200,25));
			rot_panel_left.add(output,2);
			rot_panel_left.add(output_field,3);
			
			//adding appropriate components to right panel
			rot_panel_right.add(rot_selection, 0);
			rot_panel_right.add(encrypt, 1);
			rot_panel_right.add(decrypt, 2);
			rot_panel_right.add(number_check,3);
			rot_panel_right.add(go, 4);
			rot_panel_right.add(clear, 5);
			
			//adding appropriate components to center panel
			rot_panel_center.add(rot_panel_left,0);
			rot_panel_center.add(rot_panel_right,1);
			
			//adding appropriate components to main panel
			rot_panel_main.add(rot_panel_center,1);
			
			//add the filled panels to the frame and pack it :D
			rot_frame.add(rot_panel_main);
			rot_frame.pack();
			rot_frame.setVisible(true);
		}
		
		private class AListener implements ActionListener
		{
			public void actionPerformed(ActionEvent event)
			{			
				if(event.getSource() == go)
				{	
					if(rot_selection.getSelectedItem() instanceof String  && rot_selection.getSelectedItem().equals("ROT-5"))
					{
						n = 5;
					}
					else if(rot_selection.getSelectedItem() instanceof String  && rot_selection.getSelectedItem().equals("ROT-7"))
					{
						n = 7;
					}
					else if(rot_selection.getSelectedItem() instanceof String  && rot_selection.getSelectedItem().equals("ROT-13"))
					{
						n = 13;
					}
					else if(rot_selection.getSelectedItem() instanceof String  && rot_selection.getSelectedItem().equals("ROT-17"))
					{
						n = 17;
					}	
					
					if(input_field.getText() == null || input_field.getText() == "")
						inputItem = "";
					else 
						inputItem = input_field.getText();			
					
					if(encrypt.isSelected() && decrypt.isSelected())
					{
						decrypt.setSelected(false);
						encryptON = true;
					}
					else if(encrypt.isSelected())
						encryptON = true;
					else if(decrypt.isSelected())
						encryptON = false;

					if(encryptON)
					{
						for(int i = 0; i < inputItem.length(); i++ )
						{
							if((int)inputItem.charAt(i) == 32 || (int)inputItem.charAt(i) == 33 || (int)inputItem.charAt(i) == 34 || 
									(int)inputItem.charAt(i) == 35 ||(int)inputItem.charAt(i) == 36 ||(int)inputItem.charAt(i) == 37 ||
									(int)inputItem.charAt(i) == 38 || (int)inputItem.charAt(i) == 39 || (int)inputItem.charAt(i) == 40 ||
									(int)inputItem.charAt(i) == 41 || (int)inputItem.charAt(i) == 42 || (int)inputItem.charAt(i) == 43 ||
									(int)inputItem.charAt(i) == 44 || (int)inputItem.charAt(i) == 45 || (int)inputItem.charAt(i) == 46 ||
									(int)inputItem.charAt(i) == 47 || (int)inputItem.charAt(i) == 58 || (int)inputItem.charAt(i) == 59 ||
									(int)inputItem.charAt(i) == 60 || (int)inputItem.charAt(i) == 61 || (int)inputItem.charAt(i) == 62 ||
									(int)inputItem.charAt(i) == 63 || (int)inputItem.charAt(i) == 64 || (int)inputItem.charAt(i) == 91 ||
									(int)inputItem.charAt(i) == 92 || (int)inputItem.charAt(i) == 93 || (int)inputItem.charAt(i) == 94 ||
									(int)inputItem.charAt(i) == 95 || (int)inputItem.charAt(i) == 96 || (int)inputItem.charAt(i) == 123 ||
									(int)inputItem.charAt(i) == 124 || (int)inputItem.charAt(i) == 125 || (int)inputItem.charAt(i) == 126 ||
									(int)inputItem.charAt(i) == 127)
									temp_buffer += "" + inputItem.charAt(i);
							
							if(inputItem.charAt(i) >= 'A' && inputItem.charAt(i) <= 'Z')//uppercase letter wrap around
							{
								if(inputItem.charAt(i) + n > 'Z')
								{
									temp_buffer += (char)(inputItem.charAt(i) + n - 'Z' + 'A' - 1);
								}
								else
								{
									temp_buffer += (char) (inputItem.charAt(i) + n);
								}
							} 
							else if(inputItem.charAt(i) >= 'a' && inputItem.charAt(i) <= 'z')//lowercase letter wrap around
							{
								if(inputItem.charAt(i) + n > 'z')
								{
									temp_buffer += (char) (inputItem.charAt(i) + n - 'z' + 'a' - 1);
								}
								else
								{
									temp_buffer += (char) (inputItem.charAt(i) + n);
								}
							} 
							else if(number_check.isSelected())
							{
								if(inputItem.charAt(i) >= '0' && inputItem.charAt(i) <= '9'){//decimal number wrap around
									if((inputItem.charAt(i) + n) > '9')
									{
										if(n >= 13)
											temp_buffer += (char)(((char)(inputItem.charAt(i) + n%9) - '9') + '0');
										else
											temp_buffer += (char)(((char)(inputItem.charAt(i) + n) - '9') + '0');
									}
									else
									{
										temp_buffer += (char)(inputItem.charAt(i) + n);
									}
								}
							}
							else if(!number_check.isSelected())
							{
								temp_buffer += inputItem.charAt(i);
							}
							else
							{
								temp_buffer += (char)(inputItem.charAt(i) + n);
							}
						}
					} 
					else
					{
						for(int i = 0; i < inputItem.length(); i++ )
						{	
							if((int)inputItem.charAt(i) == 32 || (int)inputItem.charAt(i) == 33 || (int)inputItem.charAt(i) == 34 || 
								(int)inputItem.charAt(i) == 35 ||(int)inputItem.charAt(i) == 36 ||(int)inputItem.charAt(i) == 37 ||
								(int)inputItem.charAt(i) == 38 || (int)inputItem.charAt(i) == 39 || (int)inputItem.charAt(i) == 40 ||
								(int)inputItem.charAt(i) == 41 || (int)inputItem.charAt(i) == 42 || (int)inputItem.charAt(i) == 43 ||
								(int)inputItem.charAt(i) == 44 || (int)inputItem.charAt(i) == 45 || (int)inputItem.charAt(i) == 46 ||
								(int)inputItem.charAt(i) == 47 || (int)inputItem.charAt(i) == 58 || (int)inputItem.charAt(i) == 59 ||
								(int)inputItem.charAt(i) == 60 || (int)inputItem.charAt(i) == 61 || (int)inputItem.charAt(i) == 62 ||
								(int)inputItem.charAt(i) == 63 || (int)inputItem.charAt(i) == 64 || (int)inputItem.charAt(i) == 91 ||
								(int)inputItem.charAt(i) == 92 || (int)inputItem.charAt(i) == 93 || (int)inputItem.charAt(i) == 94 ||
								(int)inputItem.charAt(i) == 95 || (int)inputItem.charAt(i) == 96 || (int)inputItem.charAt(i) == 123 ||
								(int)inputItem.charAt(i) == 124 || (int)inputItem.charAt(i) == 125 || (int)inputItem.charAt(i) == 126 ||
								(int)inputItem.charAt(i) == 127)
								temp_buffer += "" + inputItem.charAt(i);
								
							if(inputItem.charAt(i) >= 'A' && inputItem.charAt(i) <= 'Z')//uppercase letter wrap around
							{
								if(inputItem.charAt(i) - n < 'A'){
									temp_buffer += (char)((inputItem.charAt(i) - n) + 'Z' - 'A' + 1);
								}
								else
								{
									temp_buffer += (char) (inputItem.charAt(i) - n);
								}
							} 
							else if(inputItem.charAt(i) >= 'a' && inputItem.charAt(i) <= 'z')//lowercase letter wrap around
							{
								if(inputItem.charAt(i) - n < 'a'){
									temp_buffer += (char) ((inputItem.charAt(i) - n) + 'z' - 'a' + 1);
								}
								else
								{
									temp_buffer += (char) (inputItem.charAt(i) - n);
								}
							} 
							else if(number_check.isSelected())//decimal number wrap around
							{
								if(inputItem.charAt(i) >= '0' && inputItem.charAt(i) <= '9')
									if((inputItem.charAt(i) - n) < '0')
									{
										if(n >= 13)
											temp_buffer += (char)((char)(inputItem.charAt(i) - n%9) + '9' - '0' + 1);
										else
											temp_buffer += (char)((char)(inputItem.charAt(i) - n) + '9' - '0' + 1);
									}
									else
									{
										temp_buffer += (char)(inputItem.charAt(i) - n);
									}
							}
							else if(number_check.isSelected())
								temp_buffer += inputItem.charAt(i);
							else
							{
								temp_buffer += (char) (inputItem.charAt(i) - n);
							}
						}
					}
					output_field.setText(temp_buffer);
					temp_buffer = "";
				}
			
				if(event.getSource() == clear)
				{
					String empty = "";
					temp_buffer = empty;
					input_field.setText(empty);
					output_field.setText(empty);
				}
			}
		}
		
	}// endof#ROTFRAME

