package assignment2;

public class OverPushException extends Exception {
	public OverPushException () {
		super();
	}
	
	public OverPushException(String message) {
		super(message);
	}
}
