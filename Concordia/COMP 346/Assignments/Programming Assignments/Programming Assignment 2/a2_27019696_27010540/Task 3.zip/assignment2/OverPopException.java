package assignment2;

public class OverPopException extends Exception {
	public OverPopException() {
		super();
	}
	
	public OverPopException(String message) {
		super(message);
	}
}
