/**
 * 
 * Dequeue (Clean Ver.)
 * 
 * @author BL
 * 
 * This program implements an array as a dequeue that expands whenever it reaches 90% capacity.
 * Depending on the set expansion rule, the array's size can either double or be incremented by 10.
 * 
 * Input: Elements
 * Output: An array implementation of a dequeue which contains the elements
 * 
 * Imported packages: None
 * 
 * Known limitations: None (for now)
 * 
 */

public class Dequeue
{
	public static int head;
	public static int tail;
	char flag = 'd';	// double by default
	Element[] arr;
	
	
	// Default constructor which creates a DQ with a default size of 10
	public Dequeue()
	{
		head = 10/2;
		tail = head;
		arr = new Element[10];
	}
	
	public Dequeue(int size)
	{
		/* 1-parameter constructor that sets all the values that will be used.
		 * Head is set to the middle value because that is where we will begin
		 * adding elements. Tail is set to the head because the array is empty.
		 * An array is created with the specified size
		*/
		
		head = size/2;
		tail = head;
		arr = new Element[size];
	}
	
	// Method that will keep track of the number of elements inside the array.
	public int size()
	{
		return ((arr.length - head) + tail) % arr.length;
	}
	
	public void addFirst(Element toAdd)
	{
		if(size() + 1 > 0.9*arr.length)	// checking if the DQ is 90% full with the new element
		{
			expand();
			addFirst(toAdd);
		}else
		{
			if(head == 0)
			{
				arr[arr.length-1] = toAdd;
				head = arr.length-1;
			}else
			{
				arr[head-1] = toAdd;
				head = head - 1;
			}
		}
	}
	
	public void addLast(Element toAdd)
	{
		if(size() + 1 > 0.9*arr.length)	// checking if the DQ is 90% full with the new element
		{
			expand();
			addLast(toAdd);
		}else
		{
			if(tail == arr.length-1)	// tail is always empty
			{
				arr[arr.length-1] = toAdd;
				tail = 0;
			}else
			{
				arr[tail] = toAdd;
				tail = tail + 1;
			}
		}
	}
	
	public Element removeFirst()
	{
		if(isEmpty())
		{
			System.out.println("Cannot remove. The DQ is empty.");
			return null;
		}else
		{
			Element temp = peekFirst();
			arr[head] = null;
			if(head == arr.length-1){
				head = 0;
			}else
			{
				head = head + 1;
			}
			return temp;
		}
	}
	
	public Element removeLast()
	{
		if(isEmpty())
		{
			System.out.println("Cannot remove. The DQ is empty.");
			return null;
		}else
		{
			Element temp = peekLast();
			if(tail == 0)
			{
				arr[arr.length-1] = null;
				tail = arr.length-1;
			}else
			{
				arr[tail-1] = null;
				tail = tail - 1;
			}
			return temp;
		}
	}
	
	// Returns element at the head of the DQ
	public boolean isEmpty()
	{
		return (head == tail);
	}
	
	// Returns element at the tail of the DQ
	public Element peekFirst()
	{
		return arr[head];
	}
	
	public Element peekLast()
	{
		if(tail == 0){
			return arr[arr.length - 1];		// tail is always empty
		}else
		{
			return arr[tail - 1];
		}
	}
	
	public void truncate()
	{
		Element[] oldArr = arr;
		Element[] newArr = new Element[size()+1];
		
		// Filling up the new array starting at index 0
		for(int i = 0; i < size(); i++)
		{
			newArr[i] = oldArr[(head+i) % oldArr.length];
		}
		
		tail = size();
		head = 0;
		arr = newArr;
	}
	
	// Sets the new expansion rule
	public void setExpansionRule(char flag)
	{
		this.flag = flag;
	}
	
	// Method used to expand the array when it is 90% full
	public void expand()
	{
		Element[] oldArr = arr;
		Element[] newArr;
		
		if(flag == 'c')	// creating the new array depending on the expansion rule
		{
			newArr = new Element[oldArr.length + 10];
		}else
		{
			newArr = new Element[oldArr.length * 2];
		}
		
		// filling up the new array starting at index 0
		for(int i = 0; i < size(); i++)
		{
			newArr[i] = oldArr[(head+i) % oldArr.length];
		}
	
		tail = size();
		head = 0;
		arr = newArr;
	}
	
	public String toString()
	{
		String toReturn = "";
		
		for(int i = 0; i < arr.length; i++)
		{
			if(arr[i] == null)
				toReturn += "null ";
			else			
				toReturn += arr[i].value + " ";
		}
		
		return toReturn;
		
	}
}
