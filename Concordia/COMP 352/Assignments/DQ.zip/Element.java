public class Element
{
	public int value;
	
	/**Sets the value to zero*/
	public Element()
	{
		value = 0;
	}
	
	/**
	 * Sets the value
	 * 
	 * @param val	the value to add
	 * */
	public Element(int val)
	{
		value = val;
	}
}
