import java.lang.*;
import java.io.*;

public class ass2<D> 
{
	private static class Node<D>
	{
		private D data;
		private D link;
		private int count;
		private int size;	

		public  Node(){
			data = null;
			link = null;
			count = 0;
			size = 0;
		}

		//accessor methods
		public  D getData(){
			return (D) data;
		}

		public D getLink(){
			return  link;
		}

		public int getCount(){
			return count;
		}

		//mutator methods
		public void setData(D d){
			data = d;
		}

		public void setLink(D l){
			link = l;
		}

		public void setCount(int c){
			count =c;
		}

		//constructor
		public Node(D newData, D linkValue){
			data = newData;
			link = linkValue;

		}
	} //end of Node<D> inner class

	private Node<D> head;
	private Node<D> tail;
	private int [] array;

	public Dequeue(){ 
		head = null;


	}




	//nullPointerException method
	public String NullPointerException(String s){
		try
		{
			if((array==null)||(head==null))
				throw new NullPointerException("Array is null!");
		}
		catch (NullPointerException e) 
		{
			// display exception to screen
			System.out.println("Exception: " + e);
		}
		return s; 
	}

	//addFirst method 
	public void addFirst(D dataValue)
	{
		//head = new Node<D>(dataValue, head);
	}

	//addLast method
	public void addLast(D dataValue){
		//tail = new Node<D>(dataValue, tail);
	}

	//removeFirst method 
	public Node<D> removeFirst(){
		return head;
		
	}

	//removeLast method
	public Node<D> removeLast() {
		return head;
		
	}

	//isEmpty method
	public  Boolean isEmpty(){
		if(array==null)
			return true;
		return false;
	}

	//peekFirst method
	public Node<D> peekFirst(){
		if((head==null)||(array==null))
			return null;
		else
			return head;
	}

	//peekLast method
	public Node<D> peekLast(){
		if((tail==null)||(array==null))
			return null;
		else
			return tail;
	}

	//truncate method	
}
