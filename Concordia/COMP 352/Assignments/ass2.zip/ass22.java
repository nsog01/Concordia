

import java.util.*;


public class ass22 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String s="null";
		
		Dequeue<Integer> num1 = new Dequeue<Integer>();
		Node<Integer> m1=new Node<integer>();
		num1.addFirst(20);
		System.out.println(num1.peekFirst());
		System.out.println(num1.isEmpty());
		
	}

}
