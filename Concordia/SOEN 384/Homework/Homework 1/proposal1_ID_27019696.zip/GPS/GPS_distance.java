import com.google.android.maps.GeoPoint;  

public class GPS_Distance {  
  
   private double Radius;  
  
   // R = earth's radius (mean radius = 6,371km)  
   GPS_Distance(double R) {  
      Radius = R;  
   }  
  
   public double CalculationByDistance(GeoPoint StartP, GeoPoint EndP) {  
      double lat1 = StartP.getLatitudeE6()/1E6;  
      double lat2 = EndP.getLatitudeE6()/1E6;  
      double lon1 = StartP.getLongitudeE6()/1E6;  
      double lon2 = EndP.getLongitudeE6()/1E6;  
      double deltaLat = Math.toRadians(lat2-lat1);  
      double deltaLon = Math.toRadians(lon2-lon1);  
      double a = Math.sin(deltaLat/2) * Math.sin(deltaLat/2) +  
         Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *  
         Math.sin(deltaLon/2) * Math.sin(deltaLon/2);  
      double c = 2 * Math.asin(Math.sqrt(a));  
      return Radius * c;  
   }
}

/*
Time Recorded: 20 minutes;
Logical SLOC : 15
Rules: A source statement is considered as a block of code
that performs some action at runtime or directs 
compilers at compile time.


Tools Used:
- LocMetrics; www.locmetrics.com
- ProjectCodeMeter; www.projectcodemeter.com

LocMetrics calculated 15 logical SLOC whereas ProjectCodeMeter calculated 14

These most likely differe to the lack of counting of the declaration of the global class statement 
at the start of the file. If it did, then they would both have counted 15. Having said this,
 ProjectCodeMeter is more accurate and offers more in depth featuyres relative to the code, labour cost, logical density
 algorithmic structure, etc.
*/